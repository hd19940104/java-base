public class ModuleA {
    void print (){
        System.out.println("I am in module A");
    }
}
