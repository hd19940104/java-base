
# log4j.propertity 放在日志加载类的同级目录即可打印本地日志
# log4j.properties和src是同级目录
# -Dlog4j.configuration=<FILE_PATH>