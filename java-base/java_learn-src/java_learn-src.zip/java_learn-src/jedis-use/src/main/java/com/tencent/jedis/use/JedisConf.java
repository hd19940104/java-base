package com.tencent.jedis.use;

public class JedisConf {
    public static String redisIP = "9.134.3.226";
}
