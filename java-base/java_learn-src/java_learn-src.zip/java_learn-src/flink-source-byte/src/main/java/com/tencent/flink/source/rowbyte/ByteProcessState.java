package com.tencent.flink.source.rowbyte;

public class ByteProcessState {
    public String key;
    public long count;
    public long lastModified;
}
