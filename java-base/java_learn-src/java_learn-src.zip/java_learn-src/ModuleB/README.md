```bash
java  -cp ./moduleA-1.0-SNAPSHOT.jar:ModuleB-1.0-SNAPSHOT.jar ModuleB
or
java -jar ModuleB-1.0-SNAPSHOT-jar-with-dependencies.jar
```
